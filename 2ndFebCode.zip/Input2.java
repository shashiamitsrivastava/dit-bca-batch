// import java.io.IOException;
// import java.util.Scanner;

// // import java.util.*;
// public class Input2 {
//    static public  void main(String kajshka[]) throws IOException {


//         sum();
//         sum2("a", "d", "g");
//         // System.out.println("ENter a val");
//         // // int value = System.in.read();
//         // byte [] value = System.in.readAllBytes();
//         // System.out.println(value);

//         // Scanner scanner = new Scanner(System.in);
//         // // System.out.println("name");
//         // // String name = scanner.nextLine();
//         // // System.out.println(name);
//         // System.out.println("Roll No :");
//         // int roll = scanner.nextInt();
//         // System.out.println("This is the roll no :" + roll);
//         // // scanner.nextLine(); //this consumes the new line char
//         // System.out.println("Roll No :");
//         // float roll2 = scanner.nextFloat();
//         // System.out.println("This is the roll no :" + roll2);
//         // // System.out.println("First Name :");
//         // // String name = scanner.nextLine();
//         // // System.out.println("This is the name :" + name);

//         // Scanner scanner = new Scanner("This is Deheraun and this is DIT");
//         // int count = 0;
//         // while (scanner.hasNext()) {
//         // // System.out.println(scanner.next());
//         // scanner.next();
//         // count++;
//         // }
//         // System.out.println("This is the word count :" + count);

//         // Scanner scanner = new Scanner("This is Deheraun\n this is DIT");
//         // while (scanner.hasNext()) {
//         // System.out.println(scanner.nextLine());
//         // }

//         System.out.println("Please enter your password");
//         char[] pwd = System.console().readPassword();
//         System.out.println(new String(pwd));

//     }


//     static void sum(String [] ar){
        
//     }
//     static void sum2(String ... ar){

//     }
// }

public class Input2{
    public static void main(String[] args) {

        Stirng arg [] = new Stirng()
        System.out.println("HELLO");
    }
}
2