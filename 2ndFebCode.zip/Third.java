public class Third {
    public static void main(String[] args) {
        String name = "Shubham";
        name = name + "Sharma";
        name = name + "is good";
        // StringBuffer sb = new StringBuffer(50);
        StringBuilder sb = new StringBuilder(5);
        sb.append("S");
        // sb.append(" ");
        // sb.append("Chaudhary");

        System.out.println(sb.length());
        System.out.println(sb.capacity());
        
        
    }
}
