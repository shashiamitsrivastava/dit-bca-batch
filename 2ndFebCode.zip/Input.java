public class Input {
    public static void main(String[] args) {
        // String firstName = args[0];
        // String lastName = args[1];
        // System.out.println("This is the name :" + firstName + lastName);
        // if (args.length == 2) {
        // int num1 = Integer.parseInt(args[0]);
        // int num2 = Integer.parseInt(args[1]);
        // int res = num1 + num2;
        // System.out.println("This is the sum :" + res);
        // }
        // else{
        // System.out.println("Not a valid arg");
        // }

        int res = 0;
        for (int i = 0; i < args.length; i++) {
            res = res + Integer.parseInt(args[i]);
        }
        System.out.println("This is the sum :" + res);
    }
}

