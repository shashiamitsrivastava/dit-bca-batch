import java.io.PrintStream;

public class Byte2 {
    public static void main(String[] args) {
        byte a = 55;
        byte b = 127;
        byte d = 127;
        // byte e = b + d;

        byte c = (byte) 130;
        // PrintStream out= 
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
    }
}
