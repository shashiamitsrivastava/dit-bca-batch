package Questions;

import java.nio.file.LinkPermission;

class Laptop {

    static Laptop obj;

    // this is default constructor
    private Laptop() {

    }

    static Laptop getInstance() {
        if (obj == null) {
            obj = new Laptop();
        }
        return obj;
    }
}

public class SingleTon {
    // Laptop lap1 = new Laptop();// this is a single obj
    // Laptop lap2 = new Laptop();// this is a single obj
    // Laptop lap3 = new Laptop();// this is a single obj


    //this will create an object if it does not exist and if it does it will return it
    Laptop lap1 = Laptop.getInstance();
    Laptop lap2 = Laptop.getInstance();
    Laptop lap3 = Laptop.getInstance();

}