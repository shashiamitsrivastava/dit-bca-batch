package Questions;

public class FlipDigit {

    public static int flipDigit(int num) {
        // Convert the number to a string for easier manipulation
        String numString = Integer.toString(num);
        int length = numString.length();
        StringBuilder result = new StringBuilder();

        // Loop through each digit in the number
        for (int i = 0; i < length; i++) {
            // Get the digit at position i
            char digit = numString.charAt(i);
            int position = Character.getNumericValue(digit);
            
            // Flip the position and digit
            result.append(flipPositionDigit(num, position, i));
        }

        // Parse the final result string to integer
        return Integer.parseInt(result.toString());
    }

    // Function to flip the digit at the specified position
    private static String flipPositionDigit(int num, int position, int currentPos) {
        // Convert the number to a string for manipulation
        String numString = Integer.toString(num);
        StringBuilder result = new StringBuilder();

        // Loop through each digit in the number
        for (int i = 0; i < numString.length(); i++) {
            // If it's the position to flip, append the digit corresponding to current position
            if (i == currentPos) {
                result.append(position);
            } else {
                // Otherwise, append the digit at the current position
                result.append(numString.charAt(i));
            }
        }

        // Return the modified number as a string
        return result.toString();
    }

    public static void main(String[] args) {
        int num = 32145; // Example number

        // Call the flipDigit function
        int result = flipDigit(num);

        // Print the result
        System.out.println("Original number: " + num);
        System.out.println("Flipped number: " + result);
    }
}

