package Questions;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.text.NumberFormat;
import java.text.DateFormat;
import java.util.Date;

public class SalarySlip {
    static Locale locale;
    static ResourceBundle rb;

    static String formatSalary(double basicSalary) {
        NumberFormat nf = NumberFormat.getCurrencyInstance(locale);
        String temp = nf.format(basicSalary);
        return temp;
    }

    static void loadBundle() {
        rb = ResourceBundle.getBundle("messages", locale);
    }

    static String printDate() {
        Date date = new Date();
        DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, locale);
        return df.format(date);
    }

    static void takeInput() {

        // singleton
        Scanner scanner = new Scanner(System.in);
        // try {
        // // Set the encoding to UTF-8
        // System.setOut(new PrintStream(System.out, true, "UTF-8"));
        // } catch (UnsupportedEncodingException e) {
        // e.printStackTrace();
        // }
        System.out.println("Please select your language");
        System.out.println("Press 1 for English");
        System.out.println("हिंदी के लिए 2 दबाएँ");

        int choice = scanner.nextInt();
        if (choice == 1) {
            locale = new Locale("en", "US");
        } else if (choice == 2) {
            locale = new Locale("hi", "IN");
        } else {
            System.out.println("Invalid Choice... by default using English");
        }
        loadBundle();
        System.out.println("");
        int empID = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Please enter your Name");
        String empName = scanner.nextLine();
        System.out.println("Please enter your Basic Salary");
        double basicSalary = scanner.nextDouble();

        calculate(basicSalary, empID, empName);
    }

    static String properName(String name) {
        String[] nameArray = name.split(" ");
        String fullName = "";
        for (int i = 0; i < nameArray.length; i++) {

            String firstLetter = String.valueOf(nameArray[i].charAt(0)).toUpperCase();
            String remString = nameArray[i].substring(1).toLowerCase();
            fullName = fullName + " " + firstLetter + remString;
        }
        return fullName;
    }

    static void calculate(double basicSalary, int empID, String name) {
        double HRA = basicSalary * 0.40;
        double TA = basicSalary * 0.25;
        double DA = basicSalary * 0.20;
        double MA = basicSalary * 0.30;
        double PF = basicSalary * 0.10;
        double TAX = calcTax(basicSalary);
        String prName = properName(name);
        double gs = basicSalary + HRA + DA + TA + MA;
        double ns = gs - (TAX / 12);
        printData(empID, prName, HRA, TA, DA, MA, TAX, PF, gs, ns);
    }

    static double calcTax(double basicSalary) {
        double totSal = basicSalary * 12;
        if (totSal < 500000) {
            return 0.0 * totSal;
        } else if (totSal > 500000 && totSal < 700000) {
            return 0.10 * totSal;
        } else if (totSal > 700000 && totSal < 1000000) {
            return 0.15 * totSal;
        }
        return 0.2 * totSal;
    }

    static void printData(int empID, String name, double HRA, double TA, double DA, double MA, double TAX, double PF,
            double gs, double ns) {
        System.out.println("Today's Date :" + printDate());
        System.out.println("Welcome, " + name);
        System.out.println("This is your emp ID :" + empID);
        System.out.println("Earnings \t\tDeductions");
        System.out.println("HRA :" + formatSalary(HRA) + "\t \t TAX :" + formatSalary(TAX));
        System.out.println("TA :" + formatSalary(TA) + " \t \t PF :" + formatSalary(PF));
        System.out.println("DA :" + formatSalary(DA));
        System.out.println("MA :" + formatSalary(MA));
        System.out.println("This is your Gross Salary :" + formatSalary(gs));
        System.out.println("This is your Net Salary :" + formatSalary(ns));
    }

    public static void main(String[] args) {
        takeInput();
        // formatSalary(5000000);
    }
}
