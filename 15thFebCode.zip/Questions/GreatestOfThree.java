package Questions;

public class GreatestOfThree {
    public static void main(String[] args) {
        int first = 1000;
        int second = 454;
        int third = 55;

        if (first > second) {
            if (first > third) {
                System.out.println("First is greatest");
            } else {
                System.out.println("Third is greatest");
            }
        } else {
            if (second > third) {
                System.out.println("Second is greated");
            } else {
                System.out.println("Third is greatest");
            }
        }
    }
}
