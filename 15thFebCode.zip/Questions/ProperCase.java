package Questions;

public class ProperCase {
    public static void main(String[] args) {
        String name = "sHUbhaM ShARmA ChaUDHary";
        // Shubham Sharma

        String[] nameArray = name.split(" ");

        System.out.println(nameArray.length);
        // // nameArray[0] = sHUbhaM
        // // nameArray[1] = ShARmA
        // // nameArray[2] = ChaUDHary

        // String fullName = "";
        // for (int i = 0; i < nameArray.length; i++) {

        // String firstLetter = String.valueOf(nameArray[i].charAt(0)).toUpperCase();
        // String remString = nameArray[i].substring(1).toLowerCase();
        // fullName = fullName + " " + firstLetter + remString;
        // }
        // System.out.println("This is the name :" + fullName);

        // int z = 65;
        // int y = 97;

        // System.out.println((char)(z + 32));
        // // System.out.println((char)y);
    }
}
