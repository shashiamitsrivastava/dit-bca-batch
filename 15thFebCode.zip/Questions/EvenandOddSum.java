package Questions;

public class EvenandOddSum {
    public static void main(String[] args) {
        int num = 8765;
        int evenSum = 0;
        int oddSum = 0;
        int pos = 0;
        byte c = 5;
        byte d = 15;
        byte e = c +d;

        while (num != 0) {
            int last = num % 10;
            pos++;
            if (pos % 2 == 0) {
                evenSum = evenSum + last;
            } else {
                oddSum = oddSum + last;
            }
            num = num / 10;
        }

        System.out.println("this is the even sum :" + evenSum);
        System.out.println("this is the odd sum :" + oddSum);

    }
}
