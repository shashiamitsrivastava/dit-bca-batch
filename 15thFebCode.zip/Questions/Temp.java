package Questions;

public class Temp {
    static String properName(String name) {
        String[] nameArray = name.split(" ");
        String fullName = "";
        for (int i = 0; i < nameArray.length; i++) {

            String firstLetter = String.valueOf(nameArray[i].charAt(0)).toUpperCase();
            String remString = nameArray[i].substring(1).toLowerCase();
            fullName = fullName + " " + firstLetter + remString;
        }
        return fullName;
    }
    public static void main(String[] args) {
        properName("shuBhAM ShARmA ChAuDhaRY");
    }
}
