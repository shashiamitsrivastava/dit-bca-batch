package Questions;

public class Prime {
    public static void main(String[] args) {
        int a = 1555555;
        int count = 0;
        // for (int i = 1; i <= a; i++) {
        // if (a % i == 0) {
        // count++;
        // }
        // }
        // if (count == 2) {
        // System.out.println("The number is prime");
        // } else {
        // System.out.println("the number is not prime");
        // }

        // for (int i = 2; i < a; i++) {
        // if (a % i == 0) {
        // System.out.println("The number is prime");
        // break;
        // }
        // System.out.println("the number is not prime");
        // }

        for (int i = 2; i <= Math.sqrt(a); i++) {
            if (a % i == 0) {
                count++;
            }
        }
        if (count == 2) {
            System.out.println("The number is prime");
        } else {
            System.out.println("the number is not prime");
        }
    }
}
