package Questions;

public class Rotate {
    public static void main(String[] args) {
        int num = 12345; // 45123
        int cpynum = num;
        int count = 0;
        while (num != 0) {
            num = num / 10;
            count++;
        }
        // System.out.println("This is the len :" + count);
        int rev = 0;
        int rot = -20;

        if (rot < 0) {
            rot = rot + count;
        }
        rot = rot % count;
        // while (cpynum != 0) {
        int rhs = cpynum % (int) Math.pow(10, rot); // 45
        int lhs = cpynum / (int) Math.pow(10, rot); // 123
        rev = rhs * (int) Math.pow(10, count - rot) + lhs;
        // }
        System.out.println("This is the result :" + rev);
    }
}
