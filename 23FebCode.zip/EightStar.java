package Questions;

import java.util.*;;

public class EightStar {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the size");
        int size = scanner.nextInt();

        for (int i = 1; i < 2 * size; i++) {
            for (int j = 1; j <= size; j++) {
                if ((i == 1 || i == size || i == (2 * size) - 1) && (j == 1 || j == size)) {
                    System.out.print(" ");
                } else if (i == 1 || i == size || i == (2 * size) - 1 || j == 1 || j == size) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }

    }
}
