package Questions;

public class PrintName {

    static void printName(int count, String name) {
        // base case/ condition
        if (count == 0) {
            return;
        }
        // this is the logic
        System.out.println(name);

        // small problem(count-1)
        printName(count - 1, name);
    }

    public static void main(String[] args) {
        printName(5, "Shubham");
    }
}
