package Questions;

public class CountPrint {

    static void printCount(int count) {
        if (count == 0) {
            return;
        }
        printCount(count - 1);
        System.out.println(count);
    }

    public static void main(String[] args) {
        printCount(5);
    }
}
