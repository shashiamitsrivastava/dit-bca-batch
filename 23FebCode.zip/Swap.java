package Questions;

public class Swap {
    public static void main(String[] args) {
        int v = 12345; //52341
        int vCpy = v;
        int count = 0;
        while (v != 0) {
            v = v / 10;
            count++;
        }
        int right = vCpy % 10;
        int left = vCpy / (int) Math.pow(10, count - 1);
        int center = (vCpy % (int) Math.pow(10, count - 1)) / 10;

        int res = ((right * (int) Math.pow(10, count - 2) + center) * 10) + left;

        System.out.println("This is the result :" + res);
    }
}
