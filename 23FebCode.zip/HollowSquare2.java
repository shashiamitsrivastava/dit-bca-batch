package Questions;

public class HollowSquare2 {
    public static void main(String[] args) {
        int starCount = 5; // ***** */

        for (int j = 0; j < starCount; j++) {
            for (int i = 0; i < starCount; i++) {
                if (j == 0 || j == starCount - 1 || i == 0 || i == starCount - 1) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }

    }
}
