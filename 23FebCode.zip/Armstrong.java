package Questions;

import java.util.Scanner;

public class Armstrong {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter a value");
        int v = scanner.nextInt();
        int num = v;
        int num2 = v;
        int count = 0;
        while (num != 0) {
            num = num / 10;
            count++;
        }

        int result = 0;
        while (v != 0) {
            int last = v % 10;
            result = result + (int) Math.pow(last, count);
            v = v / 10;
        }

        if (result == num2) {
            System.out.println("The number is Armstorng");
        } else {
            System.out.println("The number is not Armstrong");
        }
    }
}