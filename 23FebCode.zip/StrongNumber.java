package Questions;

import java.util.Scanner;

public class StrongNumber {

    static int calcFact(int n) {
        int fact = 1;
        for (int i = 1; i <= n; i++) {
            fact = fact * i;
        }
        return fact;
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter a value");
        int v = scanner.nextInt();
        int num = v;
        int result = 0;
        while (v != 0) {
            int last = v % 10;
            result = result + calcFact(last);
            v = v / 10;
        }

        if (result == num) {
            System.out.println("The number is Strong");
        } else {
            System.out.println("The number is not Strong");
        }
    }
}
