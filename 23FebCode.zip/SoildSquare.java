package Questions;

public class SoildSquare {
    public static void main(String[] args) {
        int starCount = 5; // ***** */

        for (int j = 0; j < starCount; j++) {
            for (int i = 0; i < starCount; i++) {
                System.out.print("*");
            }
            System.out.println();
        }

    }
}
